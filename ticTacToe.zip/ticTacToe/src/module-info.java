/**
 * 
 */
/**
 * @author Vishakha
 *
 */
module ticTacToe {
	requires java.desktop;
}